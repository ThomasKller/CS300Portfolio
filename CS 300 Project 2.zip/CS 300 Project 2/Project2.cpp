//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : JYour name
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold Course information
struct Course {
    string courseId; // unique identifier
    string title;
    vector<string> prereqs;
};

// Internal structure for tree node
struct Node {
    Course course;
    Node *left;
    Node *right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a Course
    Node(Course aCourse) :
            Node() {
        course = aCourse;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Course course);
    void inOrder(Node* node);
    void removeNode(Node* node);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void displayPrereqs(Course course);
    void displayCourse(Course course);
    void InOrder();
    void Insert(Course course);
    void PreOrder();
    void PostOrder();
    void preOrder(Node* n);
    void postOrder(Node* n);
    void Remove(string courseId);
    Course Search(string courseId);
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    Node* root = nullptr;

}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
    // recurse from root deleting every node
    removeNode(root);
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
    // FixMe (2): In order root
    // call inOrder fuction and pass root 
    inOrder(root);
}

/**
 * Traverse the tree in post-order
 */
void BinarySearchTree::PostOrder() {
    // FixMe (3): Post order root
    postOrder(root);
}

/**
 * Traverse the tree in pre-order
 */
void BinarySearchTree::PreOrder() {
    // FixMe (4): Pre order root
    // preOrder root
    preOrder(root);
}

/**
 * Insert a Course
 */
void BinarySearchTree::Insert(Course course) {

    // if root equal to null ptr
    if (root == nullptr)
    {
        // root is equal to new node Course
        root = new Node(course);
    }

    else
    {
        // add Node root and Course
        addNode(root, course);
    } 
}

/**
 * Remove a Course
 */
void BinarySearchTree::Remove(string courseId) {
    // FIXME (6) Implement removing a Course from the tree
    // remove node root CourseID
    Node* current = root;
    Node* parent = nullptr;

    while (current != nullptr)
    {

        if (current->course.courseId == courseId)
        {
            if (current->left == nullptr && current->right == nullptr)
            {
                if (parent == nullptr)
                {
                    root = nullptr;
                   
                }
                else if (parent->left == current)
                {
                    parent->left = nullptr;
                    
                }
                else {
                    parent->right = nullptr;
                    
                }
            }

            else if (current->right == nullptr) {                // Remove node with only left child
                if (parent == nullptr) { // Node is root
                    root = current->left;
                    
                }
                else if (parent->left == current) {
                parent->left = current->left;
                
                }
                else {
                    parent->right = current->left;
                    
                }

            }
            else if (current->left == nullptr) {                // Remove node with only right child
                if (parent == nullptr) { // Node is root
                    root = current->right;
                    
                }
                else if (parent->left == current) {
                    parent->left = current->right;
                    
                }
                else {
                    parent->right = current->right;
                    
                }
            }
            else {                                      // Remove node with two children
               // Find successor (leftmost child of right subtree)
                Node* successor = current->right;
                while (successor->left != nullptr) {
                    successor = successor->left;
                }
                    
                        Node* temp = successor;
                        Remove(successor->course.courseId);     // Remove successor
                        current = temp;
                        delete temp;
                
            }
            return; // Node found and removed
        }
            
            else if (current->course.courseId < courseId) { // Search right
                parent = current;
                current = current->right;
            }
            else {                     // Search left
                parent = current;
                current = current->left;
            }
    }
}

/**
 * Search for a Course
 */
Course BinarySearchTree::Search(string CourseId) {
    Course course;
    // set current node equal to root
    Node* current = root;
    if (current == nullptr)
    {
        return course;
    }
        //while the current node contains a node
        while (current->left != nullptr || current->right != nullptr)
        {
            //if match, set Course to current Course and return 
            if (current->course.courseId == CourseId)
            {
                course = current->course;
                return course;
            }

            //if Course id is less than current Course Id
            else if (current->course.courseId > CourseId)
            {

                //checks if left is empty, makes the current node if left is not empty
                if (current->left != nullptr)
                {
                    current = current->left;
                }

                //if empty return the Course
                else
                {
                    return course;
                }
            }

            //else Course Id is bigger
            else
            {

                //check right for null, if there is a node, set current to node.
                if (current->right != nullptr)
                {
                    current = current->right;
                }
                else
                {

                    return course;
                }
            }
        }

    // keep looping downwards until bottom reached or matching CourseId found
        // if match found, return current Course

        // if Course is smaller than current node then traverse left
        // else larger so traverse right
    
    return course;
}

/**
 * Add a Course to some node (recursive)
 *
 * @param node Current node in tree
 * @param Course Course to be added
 */
void BinarySearchTree::addNode(Node* node, Course Course) {
    // if node is larger then add to left
    if (Course.courseId < node->course.courseId)
    {
        // if no left node
        if (node->left == nullptr)
        {
            // this node becomes left
            node->left = new Node(Course);
        }
        else
        {
            //else recurse down the left node
            addNode(node->left, Course);
        }     
    }
    else 
    {
        // if no right node
        if (node->right == nullptr)
        {
            // this node becomes right
            node->right = new Node(Course);
        }
        else
        {
            //else recurse down the right node
            addNode(node->right, Course);
        }

    }
        
}
void BinarySearchTree::inOrder(Node* node) {
      //diplays Courses in order
    if (node != nullptr)
    {
        inOrder(node->left);
        displayCourse(node->course);
        inOrder(node->right);
    }
   
}
void BinarySearchTree::postOrder(Node* node) {
      // FixMe (10): Pre order root
      //if node is not equal to null ptr
      //postOrder left
      //postOrder right
      //output CourseID, title, amount, fund
    if (node != nullptr)
    {
        postOrder(node->left);
        postOrder(node->right);
        displayCourse(node->course);
    }

}

void BinarySearchTree::preOrder(Node* node) {
      // FixMe (11): Pre order root
      //if node is not equal to null ptr
      //output CourseID, title, amount, fund
      //postOrder left
      //postOrder right  
    if (node != nullptr) {
        displayCourse(node->course);
        preOrder(node->left);
        preOrder(node->right);
    }
}
void BinarySearchTree::removeNode(Node* node)
{
    if (node!=nullptr)
    {
        if (node->left != nullptr)
        {
            removeNode(node->left);
        }
        if (node->right != nullptr)
        {
            removeNode(node->right);
        }
        delete node;
    }
}
void BinarySearchTree::displayCourse(Course course) {
    cout << course.courseId << ": " << course.title << endl;
    return;
}
void BinarySearchTree::displayPrereqs(Course course) {
    cout << "Prerequisites: ";
    for (int i = 0; i < course.prereqs.size(); i++)
    {
        if (i == course.prereqs.size() - 1)
        {
            cout << course.prereqs.at(i) << endl;
        }
        else {
            cout << course.prereqs.at(i) << ", ";
        }
    }
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the Course information to the console (std::out)
 *
 * @param Course struct containing the Course info
 */
void displayCourse(Course course) {
    cout << course.courseId << ": " << course.title << endl;
    return;
}
void displayPrereqs(Course course) {
    cout << "Prerequisites: ";
    for (int i=0; i<course.prereqs.size(); i++)
    {
        if (i == course.prereqs.size() - 1)
        {
            cout << course.prereqs.at(i) << endl;
        }
        else {
            cout << course.prereqs.at(i) << ", ";
        }
    }
}

/**
 * Load a CSV file containing Courses into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the Courses read
 */
void loadCourses(string csvPath, BinarySearchTree* bst) {
    //cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of Courses
            if (file[i].size() < 2)
            {
                cout << "Invalid Input" << endl;
                    break;
            }
            Course course;
            course.courseId = file[i][0];
            course.title = file[i][1];
            
            for (unsigned int j = 2; j < file[i].size(); j++)
            {
                course.prereqs.push_back(file[i][j]);
            }

           // cout << course.courseId << ", " << course.title << endl;
           // displayPrereqs(course);

            // push this Course to the end
            bst->Insert(course);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, courseKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        courseKey = "CSCI300";
        break;
    case 3:
        csvPath = argv[1];
        courseKey = argv[2];
        break;
    default:
        csvPath = "D:/Desktop/CS 300 Binary Search Tree Assignment Student Files/CourseInformation.csv";
        courseKey = "CSCI300";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a binary search tree to hold all Courses
    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    Course course;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Data Structure." << endl;
        cout << "  2. Print Course List." << endl;
        cout << "  3. Print Course" << endl;
        cout << "  9. Exit" << endl << endl;
        cout << "What would you like to do? ";
        cin >> choice;

        switch (choice) {

        default:
            cout << choice << " is not a valid option." << endl; 
            break;

        case 1:
            
            // Initialize a timer variable before loading Courses
         //   ticks = clock();

            // Complete the method call to load the Courses
            loadCourses(csvPath, bst);

            //cout << bst->Size() << " Courses read" << endl;

            // Calculate elapsed time and display result
           // ticks = clock() - ticks; // current clock ticks minus starting clock ticks
          //  cout << "time: " << ticks << " clock ticks" << endl;
           // cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            cout << "Here is a sample schedule:" << endl << endl;;
            bst->InOrder();
            break;

        case 3:
            ticks = clock();

            course = bst->Search(courseKey);

          //  ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!course.courseId.empty()) {
                displayCourse(course);
                displayPrereqs(course);
            } else {
            	cout << "Course Id " << courseKey << " not found." << endl;
            }

           // cout << "time: " << ticks << " clock ticks" << endl;
           // cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 9:
            break;

        }
    }

    cout << "Good bye." << endl;

	return 0;
}
